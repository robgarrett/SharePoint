﻿configuration Main 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [psobject]$Data,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds
    ) 
    
    Import-DscResource -ModuleName xNetworking, xTimeZone, PSDesiredStateConfiguration
    $DomainName = $Data.DomainName;
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    Node localhost
    {
        xTimeZone SetToEST {
            TimeZone = "Eastern Standard Time"
        }

        LocalConfigurationManager 
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
   }
} 